package product

class ItemController {
    static scaffold = Item
}
